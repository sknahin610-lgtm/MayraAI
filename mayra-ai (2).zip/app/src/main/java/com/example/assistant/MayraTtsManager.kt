package com.example.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

private const val TAG = "MayraTtsManager"

class MayraTtsManager(context: Context) {

    private var tts: TextToSpeech? = null
    private var femaleBengaliVoice: Voice? = null
    private var femaleEnglishVoice: Voice? = null

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var onInitialReadyCallback: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureVoices()
                _isReady.value = true
                onInitialReadyCallback?.invoke()
                onInitialReadyCallback = null
            } else {
                Log.w(TAG, "TextToSpeech initialization failed with status=$status")
            }
        }

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
            }

            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _isSpeaking.value = false
            }
        })
    }

    fun setOnInitialReady(callback: () -> Unit) {
        if (_isReady.value) {
            callback()
        } else {
            onInitialReadyCallback = callback
        }
    }

    private fun configureVoices() {
        val engine = tts ?: return
        val bnLocale = Locale.forLanguageTag("bn-BD")
        engine.language = bnLocale

        val voices = runCatching { engine.voices }.getOrNull().orEmpty()
        femaleBengaliVoice = findPreferredFemaleVoice(voices, "bn")
        femaleEnglishVoice = findPreferredFemaleVoice(voices, "en")

        femaleBengaliVoice?.let {
            engine.voice = it
        }
    }

    private fun findPreferredFemaleVoice(voices: Set<Voice>, languageCode: String): Voice? {
        val matchingLanguage = voices.filter { it.locale.language.equals(languageCode, ignoreCase = true) }
        if (matchingLanguage.isEmpty()) return null

        return matchingLanguage.firstOrNull { voice ->
            val featuresStr = voice.features?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val nameStr = voice.name.lowercase(Locale.ROOT)
            featuresStr.contains("female") || nameStr.contains("female") || nameStr.contains("bn-bd-x-ban")
        } ?: matchingLanguage.firstOrNull()
    }

    fun speak(rawText: String) {
        val engine = tts ?: return
        if (!_isReady.value) return

        val cleanText = sanitizeForSpeech(rawText)
        if (cleanText.isBlank()) return

        val hasBengaliChars = cleanText.any { it in '\u0980'..'\u09FF' }
        if (hasBengaliChars) {
            engine.language = Locale.forLanguageTag("bn-BD")
            femaleBengaliVoice?.let { engine.voice = it }
        } else {
            engine.language = Locale.US
            femaleEnglishVoice?.let { engine.voice = it }
        }

        engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "mayra_voice_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        _isReady.value = false
        _isSpeaking.value = false
    }

    private fun sanitizeForSpeech(text: String): String {
        return text
            .replace(Regex("[*#_`~>]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
