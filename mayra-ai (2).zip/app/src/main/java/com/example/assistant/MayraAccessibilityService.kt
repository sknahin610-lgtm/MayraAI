package com.example.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.util.Locale

enum class AccessibilityControlAction(
    val globalActionCode: Int,
    val labelBn: String,
    val labelEn: String,
    val feedbackBn: String,
    val feedbackEn: String,
    val minApi: Int = Build.VERSION_CODES.JELLY_BEAN
) {
    HOME(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_HOME,
        labelBn = "হোম",
        labelEn = "Home",
        feedbackBn = "হোম স্ক্রিনে যাচ্ছি",
        feedbackEn = "Going to Home screen"
    ),
    BACK(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_BACK,
        labelBn = "ব্যাক",
        labelEn = "Back",
        feedbackBn = "পিছনে যাচ্ছি",
        feedbackEn = "Navigating back"
    ),
    RECENTS(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_RECENTS,
        labelBn = "রিসেন্ট",
        labelEn = "Recents",
        feedbackBn = "রিসেন্ট অ্যাপ দেখাচ্ছি",
        feedbackEn = "Opening recent apps"
    ),
    NOTIFICATIONS(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS,
        labelBn = "নোটিফিকেশন",
        labelEn = "Notifications",
        feedbackBn = "নোটিফিকেশন প্যানেল খুলছি",
        feedbackEn = "Opening notifications"
    ),
    QUICK_SETTINGS(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS,
        labelBn = "কুইক সেটিংস",
        labelEn = "Quick Settings",
        feedbackBn = "কুইক সেটিংস খুলছি",
        feedbackEn = "Opening quick settings"
    ),
    SCREENSHOT(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT,
        labelBn = "স্ক্রিনশট",
        labelEn = "Screenshot",
        feedbackBn = "স্ক্রিনশট নিচ্ছি",
        feedbackEn = "Taking screenshot",
        minApi = Build.VERSION_CODES.P
    ),
    LOCK_SCREEN(
        globalActionCode = AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN,
        labelBn = "স্ক্রিন লক",
        labelEn = "Lock Screen",
        feedbackBn = "স্ক্রিন লক করছি",
        feedbackEn = "Locking screen",
        minApi = Build.VERSION_CODES.P
    )
}

sealed interface AccessibilityCommandOutcome {
    data class Executed(val action: AccessibilityControlAction) : AccessibilityCommandOutcome
    data class ServiceDisabled(val action: AccessibilityControlAction) : AccessibilityCommandOutcome
    data class UnsupportedApi(val action: AccessibilityControlAction) : AccessibilityCommandOutcome
}

class MayraAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceRef = WeakReference(this)
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Global-action-only service: no passive screen scraping needed.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (serviceRef?.get() === this) {
            serviceRef = null
        }
        _isConnected.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (serviceRef?.get() === this) {
            serviceRef = null
        }
        _isConnected.value = false
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var serviceRef: WeakReference<MayraAccessibilityService>? = null

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        fun detectActionCommand(rawInput: String): AccessibilityControlAction? {
            val lower = rawInput.lowercase(Locale.ROOT).trim()
            return when {
                lower.contains("স্ক্রিনশট") || lower.contains("screenshot") ->
                    AccessibilityControlAction.SCREENSHOT
                lower.contains("স্ক্রিন লক") || lower.contains("লক স্ক্রিন") || lower.contains("lock screen") ->
                    AccessibilityControlAction.LOCK_SCREEN
                lower.contains("কুইক সেটিংস") || lower.contains("quick settings") ->
                    AccessibilityControlAction.QUICK_SETTINGS
                lower.contains("নোটিফিকেশন") || lower.contains("notifications") ->
                    AccessibilityControlAction.NOTIFICATIONS
                lower.contains("রিসেন্ট") || lower.contains("recent apps") || lower.contains("recents") ->
                    AccessibilityControlAction.RECENTS
                lower == "হোম" || lower.contains("হোমে যাও") || lower.contains("হোম স্ক্রিন") ||
                    lower.contains("go home") || lower == "home" ->
                    AccessibilityControlAction.HOME
                lower == "ব্যাক" || lower.contains("ব্যাক করো") || lower.contains("পিছনে যাও") ||
                    lower.contains("go back") || lower == "back" ->
                    AccessibilityControlAction.BACK
                else -> null
            }
        }

        fun performAction(action: AccessibilityControlAction): AccessibilityCommandOutcome {
            if (Build.VERSION.SDK_INT < action.minApi) {
                return AccessibilityCommandOutcome.UnsupportedApi(action)
            }
            val service = serviceRef?.get() ?: return AccessibilityCommandOutcome.ServiceDisabled(action)
            val ok = service.performGlobalAction(action.globalActionCode)
            return if (ok) {
                AccessibilityCommandOutcome.Executed(action)
            } else {
                AccessibilityCommandOutcome.ServiceDisabled(action)
            }
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
