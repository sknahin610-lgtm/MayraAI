package com.example.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import java.util.Locale

enum class QuickAppTarget(
    val displayName: String,
    val packageName: String?
) {
    YOUTUBE("YouTube", "com.google.android.youtube"),
    WHATSAPP("WhatsApp", "com.whatsapp"),
    CAMERA("Camera", null),
    CHROME("Chrome", "com.android.chrome")
}

data class InstalledAppInfo(
    val label: String,
    val packageName: String
)

sealed interface AppLaunchOutcome {
    data class Launched(val appName: String, val feedbackBn: String, val feedbackEn: String) : AppLaunchOutcome
    data class NotAvailable(val appName: String, val feedbackBn: String, val feedbackEn: String) : AppLaunchOutcome
}

object DeviceAppLauncher {

    fun detectAppCommand(rawInput: String): QuickAppTarget? {
        val normalized = rawInput.lowercase(Locale.ROOT).trim()
        val looksLikeOpenCommand = normalized.contains("open") ||
            normalized.contains("launch") ||
            normalized.contains("start") ||
            normalized.contains("খোল") ||
            normalized.contains("চালু") ||
            normalized.contains("ওপেন") ||
            normalized.split(Regex("\\s+")).size <= 3

        if (!looksLikeOpenCommand) return null

        return when {
            normalized.contains("ইউটিউব") || normalized.contains("youtube") -> QuickAppTarget.YOUTUBE
            normalized.contains("হোয়াটসঅ্যাপ") ||
                normalized.contains("হোয়াটসঅ্যাপ") ||
                normalized.contains("whatsapp") -> QuickAppTarget.WHATSAPP
            normalized.contains("ক্যামেরা") || normalized.contains("camera") -> QuickAppTarget.CAMERA
            normalized.contains("ক্রোম") || normalized.contains("chrome") -> QuickAppTarget.CHROME
            else -> null
        }
    }

    fun detectSystemUtilityIntent(rawInput: String): Pair<String, Intent>? {
        val normalized = rawInput.lowercase(Locale.ROOT).trim()
        return when {
            normalized.contains("সেটিংস") || normalized.contains("settings") ->
                "Settings" to Intent(Settings.ACTION_SETTINGS)
            normalized.contains("ডায়ালার") || normalized.contains("ডায়ালার") ||
                normalized == "ফোন" || normalized.contains("ফোন খোলো") ||
                normalized.contains("dialer") || normalized.contains("open phone") ->
                "Phone" to Intent(Intent.ACTION_DIAL)
            else -> null
        }
    }

    fun queryInstalledApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        val selfPackage = context.packageName
        return resolveInfos
            .asSequence()
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == selfPackage) return@mapNotNull null
                val label = info.loadLabel(pm).toString().trim()
                if (label.isBlank()) return@mapNotNull null
                InstalledAppInfo(label = label, packageName = pkg)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.ROOT) }
            .toList()
    }

    fun launch(context: Context, target: QuickAppTarget): AppLaunchOutcome {
        return when (target) {
            QuickAppTarget.CAMERA -> launchCamera(context)
            QuickAppTarget.YOUTUBE,
            QuickAppTarget.WHATSAPP,
            QuickAppTarget.CHROME -> launchPackage(
                context = context,
                packageName = target.packageName.orEmpty(),
                displayName = target.displayName
            )
        }
    }

    fun launchPackage(context: Context, packageName: String, displayName: String): AppLaunchOutcome {
        if (packageName.isBlank()) {
            return AppLaunchOutcome.NotAvailable(
                appName = displayName,
                feedbackBn = "$displayName অ্যাপ পাওয়া যায়নি",
                feedbackEn = "$displayName app was not found."
            )
        }
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            try {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                AppLaunchOutcome.Launched(
                    appName = displayName,
                    feedbackBn = "$displayName খুলছি",
                    feedbackEn = "Opening $displayName"
                )
            } catch (_: Exception) {
                AppLaunchOutcome.NotAvailable(
                    appName = displayName,
                    feedbackBn = "$displayName খোলা যাচ্ছে না",
                    feedbackEn = "Unable to open $displayName."
                )
            }
        } else {
            AppLaunchOutcome.NotAvailable(
                appName = displayName,
                feedbackBn = "$displayName অ্যাপ পাওয়া যায়নি",
                feedbackEn = "$displayName app is not installed."
            )
        }
    }

    fun launchIntent(context: Context, displayName: String, intent: Intent): AppLaunchOutcome {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            AppLaunchOutcome.Launched(
                appName = displayName,
                feedbackBn = "$displayName খুলছি",
                feedbackEn = "Opening $displayName"
            )
        } catch (_: Exception) {
            AppLaunchOutcome.NotAvailable(
                appName = displayName,
                feedbackBn = "$displayName খোলা যাচ্ছে না",
                feedbackEn = "Unable to open $displayName."
            )
        }
    }

    private fun launchCamera(context: Context): AppLaunchOutcome {
        return launchIntent(
            context = context,
            displayName = QuickAppTarget.CAMERA.displayName,
            intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
    }
}
