package com.example.data.local

import kotlinx.coroutines.flow.Flow
import java.util.Locale

data class MemoryCommandMatch(
    val content: String,
    val category: String
)

class MemoryRepository(private val dao: MemoryFactDao) {

    val allMemories: Flow<List<MemoryFactEntity>> = dao.getAllMemories()

    suspend fun getRecentMemoriesSnapshot(limit: Int = 20): List<MemoryFactEntity> =
        dao.getRecentMemoriesSnapshot(limit)

    suspend fun saveMemory(content: String, category: String = MemoryFactEntity.CATEGORY_NOTE) {
        val cleaned = content.trim()
        if (cleaned.isNotEmpty()) {
            dao.insertMemory(
                MemoryFactEntity(
                    content = cleaned,
                    category = category
                )
            )
        }
    }

    suspend fun deleteMemory(id: Int) = dao.deleteMemoryById(id)

    suspend fun clearAll() = dao.clearAllMemories()

    companion object {
        fun detectMemoryCommand(rawInput: String): MemoryCommandMatch? {
            val trimmed = rawInput.trim()
            val lower = trimmed.lowercase(Locale.ROOT)

            val bengaliPrefixes = listOf("মনে রাখো", "মনে রেখো", "নোট করো", "সেভ করো")
            for (prefix in bengaliPrefixes) {
                if (lower.startsWith(prefix)) {
                    val payload = trimmed.substring(prefix.length).trim(' ', ':', '-', '।', ',')
                    if (payload.isNotBlank()) {
                        val category = if (payload.contains("সময়") || payload.contains("টার") || payload.contains("কাল")) {
                            MemoryFactEntity.CATEGORY_REMINDER
                        } else {
                            MemoryFactEntity.CATEGORY_NOTE
                        }
                        return MemoryCommandMatch(payload, category)
                    }
                }
            }

            val englishPrefixes = listOf("remember that", "remember", "save note", "note that")
            for (prefix in englishPrefixes) {
                if (lower.startsWith(prefix)) {
                    val payload = trimmed.substring(prefix.length).trim(' ', ':', '-', ',', '.')
                    if (payload.isNotBlank()) {
                        return MemoryCommandMatch(payload, MemoryFactEntity.CATEGORY_NOTE)
                    }
                }
            }

            if ((lower.startsWith("আমার নাম ") || lower.startsWith("my name is ")) &&
                !lower.contains("?") && !lower.contains("কি") && !lower.contains("কী")
            ) {
                return MemoryCommandMatch(trimmed, MemoryFactEntity.CATEGORY_PERSONAL)
            }

            return null
        }
    }
}
