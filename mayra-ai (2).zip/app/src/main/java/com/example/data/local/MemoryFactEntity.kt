package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memory_facts")
data class MemoryFactEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    val category: String = CATEGORY_NOTE,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val CATEGORY_PERSONAL = "personal"
        const val CATEGORY_REMINDER = "reminder"
        const val CATEGORY_NOTE = "note"
    }
}
