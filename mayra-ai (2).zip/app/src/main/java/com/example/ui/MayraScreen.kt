package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.assistant.DeviceAppLauncher
import com.example.assistant.SpeechRecognitionState
import com.example.ui.components.AppsAndControlTab
import com.example.ui.components.ConversationFeed
import com.example.ui.components.MayraOrbStage
import com.example.ui.components.MemoryAndServerTab
import com.example.ui.components.QuickAppsDock
import com.example.ui.components.VoiceServiceBar

@Composable
fun MayraScreen(
    viewModel: MayraViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    BackHandler(enabled = state.selectedTab != MayraTab.ASSISTANT) {
        viewModel.selectTab(MayraTab.ASSISTANT)
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.startVoiceListening() else viewModel.onMicPermissionDenied()
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.onCameraPermissionResult(granted)
    }

    val backgroundVoicePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val audioGranted = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (audioGranted) viewModel.startBackgroundVoiceService() else viewModel.onMicPermissionDenied()
    }

    val handleStartVoiceService: () -> Unit = {
        val missingPermissions = buildList {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.RECORD_AUDIO)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (missingPermissions.isEmpty()) {
            viewModel.startBackgroundVoiceService()
        } else {
            backgroundVoicePermissionsLauncher.launch(missingPermissions.toTypedArray())
        }
    }

    val handleHandsFreeToggle: () -> Unit = {
        if (state.isBackgroundVoiceActive) viewModel.stopBackgroundVoiceService()
        else handleStartVoiceService()
    }

    LaunchedEffect(viewModel) {
        viewModel.cameraPermissionRequests.collect {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    LaunchedEffect(Unit) {
        if (state.allTimeVoiceEnabled && !state.isBackgroundVoiceActive) {
            handleStartVoiceService()
        }
    }

    val handleMicClick: () -> Unit = {
        if (state.isBackgroundVoiceActive) {
            viewModel.stopBackgroundVoiceService()
        } else if (state.speechState is SpeechRecognitionState.Listening) {
            viewModel.stopVoiceListening()
        } else {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) viewModel.startVoiceListening()
            else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val bgVoid = MaterialTheme.colorScheme.background
    val bgGlowPrimary = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
    val bgGlowSecondary = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.10f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgVoid)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(bgGlowPrimary, bgVoid.copy(alpha = 0f)),
                        center = Offset(size.width * 0.5f, size.height * 0.16f),
                        radius = size.maxDimension * 0.52f
                    ),
                    center = Offset(size.width * 0.5f, size.height * 0.16f),
                    radius = size.maxDimension * 0.52f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(bgGlowSecondary, bgVoid.copy(alpha = 0f)),
                        center = Offset(size.width * 0.88f, size.height * 0.78f),
                        radius = size.maxDimension * 0.42f
                    ),
                    center = Offset(size.width * 0.88f, size.height * 0.78f),
                    radius = size.maxDimension * 0.42f
                )
            }
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideLayout = maxWidth >= 840.dp

            Row(modifier = Modifier.fillMaxSize()) {
                if (isWideLayout) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                        modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        MayraTab.entries.forEach { tab ->
                            NavigationRailItem(
                                selected = state.selectedTab == tab,
                                onClick = { viewModel.selectTab(tab) },
                                icon = { Icon(iconForTab(tab), contentDescription = null) },
                                label = { Text(labelForTab(tab, state.language)) },
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .imePadding()
                ) {
                    MayraTopHeader(
                        language = state.language,
                        autoSpeakEnabled = state.autoSpeakEnabled,
                        isBackgroundVoiceActive = state.isBackgroundVoiceActive,
                        hasMessages = state.messages.isNotEmpty(),
                        onToggleLanguage = viewModel::toggleLanguage,
                        onToggleAutoSpeak = viewModel::toggleAutoSpeak,
                        onToggleHandsFree = handleHandsFreeToggle,
                        onClearChat = viewModel::clearConversation,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        when (state.selectedTab) {
                            MayraTab.ASSISTANT -> AssistantTabContent(
                                state = state,
                                isWideLayout = isWideLayout,
                                onOrbClick = handleMicClick,
                                onStartVoiceService = handleStartVoiceService,
                                onStopVoiceService = viewModel::stopBackgroundVoiceService,
                                onLaunchQuickApp = { viewModel.launchQuickApp(it) },
                                onSuggestionClick = viewModel::submitPrompt,
                                onToggleSpeakMessage = viewModel::toggleSpeakMessage,
                                onRetryError = viewModel::retryLastFailed,
                                onDismissError = viewModel::dismissError,
                                onInputChanged = viewModel::onInputTextChanged,
                                onSend = {
                                    keyboardController?.hide()
                                    viewModel.submitCurrentInput()
                                },
                                onMicClick = handleMicClick
                            )

                            MayraTab.APPS_CONTROL -> AppsAndControlTab(
                                language = state.language,
                                isAccessibilityEnabled = state.isAccessibilityEnabled,
                                installedApps = state.installedApps,
                                searchQuery = state.appSearchQuery,
                                onSearchQueryChanged = viewModel::onAppSearchQueryChanged,
                                onRefreshApps = viewModel::refreshInstalledApps,
                                onLaunchInstalledApp = { viewModel.launchInstalledApp(it) },
                                onOpenAccessibilitySettings = viewModel::openAccessibilitySettings,
                                onPerformAccessibilityAction = { viewModel.triggerAccessibilityAction(it) },
                                onLaunchDialer = {
                                    DeviceAppLauncher.launchIntent(context, "Phone", Intent(Intent.ACTION_DIAL))
                                },
                                onLaunchSettings = {
                                    DeviceAppLauncher.launchIntent(context, "Settings", Intent(Settings.ACTION_SETTINGS))
                                },
                                modifier = Modifier.widthIn(max = 760.dp)
                            )

                            MayraTab.MEMORY_AI -> MemoryAndServerTab(
                                language = state.language,
                                aiServerStatus = state.aiServerStatus,
                                memories = state.memories,
                                memoryInputText = state.memoryInputText,
                                onTestAiServer = viewModel::testAiServerConnection,
                                onMemoryInputChanged = viewModel::onMemoryInputChanged,
                                onAddMemory = viewModel::addMemoryFromInput,
                                onDeleteMemory = viewModel::deleteMemory,
                                onClearAllMemories = viewModel::clearAllMemories,
                                modifier = Modifier.widthIn(max = 760.dp)
                            )
                        }
                    }

                    if (!isWideLayout) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            MayraTab.entries.forEach { tab ->
                                NavigationBarItem(
                                    selected = state.selectedTab == tab,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = { Icon(iconForTab(tab), contentDescription = null) },
                                    label = {
                                        Text(
                                            text = labelForTab(tab, state.language),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AssistantTabContent(
    state: MayraUiState,
    isWideLayout: Boolean,
    onOrbClick: () -> Unit,
    onStartVoiceService: () -> Unit,
    onStopVoiceService: () -> Unit,
    onLaunchQuickApp: (com.example.assistant.QuickAppTarget) -> Unit,
    onSuggestionClick: (String) -> Unit,
    onToggleSpeakMessage: (ChatMessage) -> Unit,
    onRetryError: () -> Unit,
    onDismissError: () -> Unit,
    onInputChanged: (String) -> Unit,
    onSend: () -> Unit,
    onMicClick: () -> Unit
) {
    val listeningState = state.speechState as? SpeechRecognitionState.Listening
    val isListening = listeningState != null || (state.isBackgroundVoiceActive && state.isServiceListening)
    val isThinking = state.aiState is AiUiState.Loading
    val isSpeakingAny = state.isSpeaking || (state.isBackgroundVoiceActive && state.isServiceSpeaking)
    val effectiveStatusText = when (val speech = state.speechState) {
        is SpeechRecognitionState.Listening -> speech.partialTranscript.ifBlank {
            stringResource(
                id = if (state.language == AssistantLanguage.BENGALI) R.string.status_listening_bn
                else R.string.status_listening_en
            )
        }
        is SpeechRecognitionState.Error -> speech.message
        SpeechRecognitionState.Idle -> when {
            state.isBackgroundVoiceActive && state.isServiceSpeaking ->
                stringResource(
                    id = if (state.language == AssistantLanguage.BENGALI) R.string.status_speaking_bn
                    else R.string.status_speaking_en
                )
            state.isBackgroundVoiceActive && state.isServiceListening ->
                stringResource(
                    id = if (state.language == AssistantLanguage.BENGALI) R.string.status_listening_bn
                    else R.string.status_listening_en
                )
            else -> state.statusBanner
        }
    }

    if (isWideLayout) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 1040.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(0.42f)
                    .fillMaxHeight()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                MayraOrbStage(
                    statusText = effectiveStatusText,
                    isListening = isListening,
                    isThinking = isThinking,
                    isSpeaking = isSpeakingAny,
                    rmsDb = listeningState?.rmsDb ?: 0f,
                    orbSize = 124.dp,
                    onOrbClick = onOrbClick
                )
                VoiceServiceBar(
                    isActive = state.isBackgroundVoiceActive,
                    isListening = state.isServiceListening,
                    isSpeaking = state.isServiceSpeaking,
                    language = state.language,
                    onStartVoiceService = onStartVoiceService,
                    onStopVoiceService = onStopVoiceService
                )
                QuickAppsDock(language = state.language, onLaunchApp = onLaunchQuickApp)
            }

            Column(modifier = Modifier.weight(0.58f).fillMaxHeight()) {
                ConversationFeed(
                    messages = state.messages,
                    aiState = state.aiState,
                    language = state.language,
                    speakingMessageId = state.speakingMessageId,
                    onSuggestionClick = onSuggestionClick,
                    onToggleSpeakMessage = onToggleSpeakMessage,
                    onRetryError = onRetryError,
                    onDismissError = onDismissError,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                ComposerDock(
                    inputText = state.inputText,
                    language = state.language,
                    isListening = isListening,
                    isThinking = isThinking,
                    onInputChanged = onInputChanged,
                    onSend = onSend,
                    onMicClick = onMicClick
                )
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            MayraOrbStage(
                statusText = effectiveStatusText,
                isListening = isListening,
                isThinking = isThinking,
                isSpeaking = isSpeakingAny,
                rmsDb = listeningState?.rmsDb ?: 0f,
                orbSize = if (state.messages.isEmpty()) 88.dp else 64.dp,
                onOrbClick = onOrbClick
            )
            Spacer(modifier = Modifier.height(6.dp))
            VoiceServiceBar(
                isActive = state.isBackgroundVoiceActive,
                isListening = state.isServiceListening,
                isSpeaking = state.isServiceSpeaking,
                language = state.language,
                onStartVoiceService = onStartVoiceService,
                onStopVoiceService = onStopVoiceService
            )
            Spacer(modifier = Modifier.height(8.dp))
            QuickAppsDock(language = state.language, onLaunchApp = onLaunchQuickApp)
            Spacer(modifier = Modifier.height(8.dp))
            ConversationFeed(
                messages = state.messages,
                aiState = state.aiState,
                language = state.language,
                speakingMessageId = state.speakingMessageId,
                onSuggestionClick = onSuggestionClick,
                onToggleSpeakMessage = onToggleSpeakMessage,
                onRetryError = onRetryError,
                onDismissError = onDismissError,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            ComposerDock(
                inputText = state.inputText,
                language = state.language,
                isListening = isListening,
                isThinking = isThinking,
                onInputChanged = onInputChanged,
                onSend = onSend,
                onMicClick = onMicClick
            )
        }
    }
}

@Composable
private fun MayraTopHeader(
    language: AssistantLanguage,
    autoSpeakEnabled: Boolean,
    isBackgroundVoiceActive: Boolean,
    hasMessages: Boolean,
    onToggleLanguage: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onToggleHandsFree: () -> Unit,
    onClearChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_mayra_logo),
                contentDescription = stringResource(id = R.string.cd_mayra_orb),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(id = R.string.mayra_brand_title),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = stringResource(
                        id = if (language == AssistantLanguage.BENGALI) R.string.mayra_subtitle_bn
                        else R.string.mayra_subtitle_en
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Surface(
                onClick = onToggleHandsFree,
                shape = MaterialTheme.shapes.extraLarge,
                color = if (isBackgroundVoiceActive) MaterialTheme.colorScheme.secondaryContainer
                else MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    1.dp,
                    if (isBackgroundVoiceActive) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                ),
                modifier = Modifier.minimumInteractiveComponentSize().testTag("handsfree_toggle")
            ) {
                Icon(
                    imageVector = Icons.Rounded.GraphicEq,
                    contentDescription = stringResource(id = R.string.cd_handsfree_toggle),
                    tint = if (isBackgroundVoiceActive) MaterialTheme.colorScheme.onSecondaryContainer
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).size(18.dp)
                )
            }

            Surface(
                onClick = onToggleLanguage,
                shape = MaterialTheme.shapes.extraLarge,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                modifier = Modifier.minimumInteractiveComponentSize().testTag("language_toggle")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Translate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = language.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            IconButton(
                onClick = onToggleAutoSpeak,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("autospeak_toggle")
            ) {
                Icon(
                    imageVector = if (autoSpeakEnabled) Icons.AutoMirrored.Rounded.VolumeUp
                    else Icons.AutoMirrored.Rounded.VolumeOff,
                    contentDescription = stringResource(id = R.string.cd_voice_toggle),
                    tint = if (autoSpeakEnabled) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(visible = hasMessages) {
                IconButton(
                    onClick = onClearChat,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("clear_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteSweep,
                        contentDescription = stringResource(id = R.string.cd_clear_chat),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ComposerDock(
    inputText: String,
    language: AssistantLanguage,
    isListening: Boolean,
    isThinking: Boolean,
    onInputChanged: (String) -> Unit,
    onSend: () -> Unit,
    onMicClick: () -> Unit
) {
    val micContainerColor by animateColorAsState(
        targetValue = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
        label = "mic_bg_color"
    )
    val micContentColor by animateColorAsState(
        targetValue = if (isListening) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary,
        label = "mic_fg_color"
    )

    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = inputText,
            onValueChange = onInputChanged,
            placeholder = {
                Text(
                    text = stringResource(
                        id = if (language == AssistantLanguage.BENGALI) R.string.input_hint_bn
                        else R.string.input_hint_en
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            singleLine = true,
            shape = MaterialTheme.shapes.extraLarge,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            trailingIcon = {
                if (inputText.isNotBlank() && !isThinking) {
                    IconButton(
                        onClick = onSend,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.Send,
                            contentDescription = stringResource(id = R.string.cd_send_button),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            modifier = Modifier.weight(1f).testTag("prompt_input")
        )

        FilledIconButton(
            onClick = onMicClick,
            shape = CircleShape,
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = micContainerColor,
                contentColor = micContentColor
            ),
            modifier = Modifier.size(54.dp).minimumInteractiveComponentSize().testTag("mic_button")
        ) {
            Icon(
                imageVector = if (isListening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                contentDescription = stringResource(id = R.string.cd_mic_button),
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

private fun iconForTab(tab: MayraTab) = when (tab) {
    MayraTab.ASSISTANT -> Icons.Rounded.AutoAwesome
    MayraTab.APPS_CONTROL -> Icons.Rounded.Apps
    MayraTab.MEMORY_AI -> Icons.Rounded.Memory
}

@Composable
private fun labelForTab(tab: MayraTab, language: AssistantLanguage): String {
    val isBn = language == AssistantLanguage.BENGALI
    return stringResource(
        id = when (tab) {
            MayraTab.ASSISTANT -> if (isBn) R.string.nav_assistant_bn else R.string.nav_assistant_en
            MayraTab.APPS_CONTROL -> if (isBn) R.string.nav_launcher_bn else R.string.nav_launcher_en
            MayraTab.MEMORY_AI -> if (isBn) R.string.nav_memory_bn else R.string.nav_memory_en
        }
    )
}
