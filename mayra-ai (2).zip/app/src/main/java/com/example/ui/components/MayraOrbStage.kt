package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R

@Composable
fun MayraOrbStage(
    statusText: String,
    isListening: Boolean,
    isThinking: Boolean,
    isSpeaking: Boolean,
    rmsDb: Float,
    orbSize: Dp = 112.dp,
    onOrbClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val tertiaryColor = MaterialTheme.colorScheme.tertiary

    val infiniteTransition = rememberInfiniteTransition(label = "mayra_orb_pulse")
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isThinking) 1800 else 5500,
                easing = LinearEasing
            )
        ),
        label = "orbit_angle"
    )

    val voiceBoost by animateFloatAsState(
        targetValue = if (isListening) 1f + (rmsDb / 18f) else 1f,
        animationSpec = spring(stiffness = 380f),
        label = "voice_boost"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(orbSize + 34.dp)
                .clip(CircleShape)
                .clickable(onClick = onOrbClick)
                .testTag("mayra_orb_button"),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = (size.minDimension / 2f) * 0.72f
                val activeScale = when {
                    isListening -> voiceBoost
                    isSpeaking -> idlePulse * 1.08f
                    else -> idlePulse
                }

                // Soft atmospheric outer glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryColor.copy(alpha = if (isListening || isSpeaking) 0.36f else 0.20f),
                            secondaryColor.copy(alpha = if (isThinking) 0.22f else 0.08f),
                            primaryColor.copy(alpha = 0f)
                        ),
                        center = center,
                        radius = (size.minDimension / 2f) * activeScale
                    ),
                    radius = (size.minDimension / 2f) * activeScale,
                    center = center
                )

                // Rotating aurora ring
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            primaryColor.copy(alpha = 0.85f),
                            secondaryColor.copy(alpha = 0.75f),
                            tertiaryColor.copy(alpha = 0.45f),
                            primaryColor.copy(alpha = 0.12f),
                            primaryColor.copy(alpha = 0.85f)
                        ),
                        center = center
                    ),
                    startAngle = orbitAngle,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = Stroke(width = if (isListening || isThinking) 3.5.dp.toPx() else 2.dp.toPx()),
                    topLeft = Offset(
                        center.x - baseRadius * activeScale,
                        center.y - baseRadius * activeScale
                    ),
                    size = androidx.compose.ui.geometry.Size(
                        baseRadius * 2f * activeScale,
                        baseRadius * 2f * activeScale
                    )
                )
            }

            Image(
                painter = painterResource(id = R.drawable.img_mayra_logo),
                contentDescription = stringResource(id = R.string.cd_mayra_orb),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(orbSize)
                    .clip(CircleShape)
                    .border(
                        width = 1.5.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                        shape = CircleShape
                    )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
            tonalElevation = 2.dp
        ) {
            AnimatedContent(
                targetState = statusText,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                },
                label = "status_banner_anim"
            ) { currentStatus ->
                Text(
                    text = currentStatus,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = if (isListening) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}
