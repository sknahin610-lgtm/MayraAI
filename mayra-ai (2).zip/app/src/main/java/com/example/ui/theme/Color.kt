package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Celestial Midnight palette anchored by Mayra AI's signature deep indigo (#0C142B)
val MidnightVoid = Color(0xFF0C142B)
val MidnightSurface = Color(0xFF121D3A)
val MidnightSurfaceVariant = Color(0xFF1A284E)
val MidnightElevated = Color(0xFF233564)

val IceBluePrimary = Color(0xFF82B4FF)
val IceBlueOnPrimary = Color(0xFF071A3C)
val IceBlueContainer = Color(0xFF2B4C82)
val IceBlueOnContainer = Color(0xFFDCE9FF)

val AuroraCyanSecondary = Color(0xFF67E8F9)
val AuroraCyanOnSecondary = Color(0xFF06252B)
val AuroraCyanContainer = Color(0xFF144253)
val AuroraCyanOnContainer = Color(0xFFCFFAFE)

val StarlightVioletTertiary = Color(0xFFB8A4FF)
val StarlightOnTertiary = Color(0xFF22134A)
val StarlightContainer = Color(0xFF39286E)
val StarlightOnContainer = Color(0xFFEDE7FF)

val StarlightWhite = Color(0xFFF3F6FF)
val MistGray = Color(0xFFAAB8D6)
val CosmicOutline = Color(0xFF314472)
val CosmicOutlineVariant = Color(0xFF223158)

val RoseError = Color(0xFFFF8A9B)
val RoseErrorContainer = Color(0xFF5C1A28)
val RoseOnError = Color(0xFF3F0612)
val RoseOnErrorContainer = Color(0xFFFFD9DF)

// Brand accents for quick-launch tiles
val YouTubeAccent = Color(0xFFFF5A5F)
val WhatsAppAccent = Color(0xFF34D399)
val CameraAccent = Color(0xFFFBBF24)
val ChromeAccent = Color(0xFF60A5FA)

// Light fallback palette (when light theme is explicitly selected)
val DaylightBackground = Color(0xFFF4F7FF)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFE7EEFC)
val DaylightPrimary = Color(0xFF2B4C82)
val DaylightOnPrimary = Color(0xFFFFFFFF)
val DaylightTextPrimary = Color(0xFF0F172A)
val DaylightTextSecondary = Color(0xFF475569)
